-- Average Interest Rates

select avg(int_rate)*100 as Average_Interest_Rates from Bank_Loan_Data 

select avg(int_rate)*100 as MTD_Average_Interest_Rates from Bank_Loan_Data 
where month(issue_date)=12

select avg(int_rate)*100 as PMTD_Average_Interest_Rates from Bank_Loan_Data 
where month(issue_date)=11