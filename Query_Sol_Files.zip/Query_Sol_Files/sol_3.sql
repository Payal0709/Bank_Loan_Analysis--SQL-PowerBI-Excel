-- Total Amount Received

select sum(total_payment) as Total_Amount_Received from Bank_Loan_Data 

select sum(total_payment) as MTD_Total_Amount_Received from bank_loan_data
where month(issue_date)=12

select sum(total_payment) as PMTD_Total_Amount_Received from bank_loan_data
where month(issue_date)=11