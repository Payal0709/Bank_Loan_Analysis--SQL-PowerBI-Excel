-- Total Loan Applications
SELECT COUNT(id) AS Total_Loan_Applications FROM bank_loan_data

select count(id) as MTD_Total_Loan_Applications FROM bank_loan_data
where month(issue_date)=12

select count(id) as PMTD_Total_Loan_Applications FROM bank_loan_data
where month(issue_date)=11
