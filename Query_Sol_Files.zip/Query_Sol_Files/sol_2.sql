-- Total Funded Amount

select sum(loan_amount) as Total_Funded_Amount from Bank_Loan_Data 

select sum(loan_amount) as MTD_Total_Funded_Amount from bank_loan_data
where month(issue_date)=12

select sum(loan_amount) as PMTD_Total_Funded_Amount from bank_loan_data
where month(issue_date)=11
